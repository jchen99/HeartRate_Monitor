# HealthApp

https://www.youtube.com/watch?v=B7JnIES8mRw 
watch Full video on Youtube and understand the concept of gridview builder

<img src="screenshot/screen.png" width="400px">



